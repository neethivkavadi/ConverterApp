package com.example.converterapp;

import androidx.appcompat.app.AppCompatActivity;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.EditText;
import android.os.Bundle;
import android.widget.Toast;
import java.text.DecimalFormat;

/*
 *       This activity has 1 input with 1 Spinner (with 4 values)
 *       and 1 button that produces 3 outputs.
 *
 *       Inputs:
 *       1. Value to convert
 *       2. Spinner:
 *          - "Select Data Type"
 *          - "Miles"
 *          - "Kilometers"
 *          - "Yards"
 *
 *       Button with corresponding onClick:
 *       1. Convert     -   Convert()
 *
 *       Outputs:
 *       1. Miles
 *       2. Kilometers
 *       3. Yards
 *
 */

public class DistanceActivity2 extends AppCompatActivity {

    // input with spinner
    private EditText e1;
    private Spinner spinner;
    private int choice = 0;

    // output
    private TextView d1;
    private TextView d2;
    private TextView d3;

    private static DecimalFormat df2 = new DecimalFormat("#.##");
    private static final String TAG = "DistanceActivity2";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_distance2);

        // input
        e1 = findViewById(R.id.input);

        //output
        d1 = findViewById(R.id.display1);
        d2 = findViewById(R.id.display2);
        d3 = findViewById(R.id.display3);

        Log.d(TAG, "onCreate: Entered Activity");

        // spinner
        spinner = findViewById(R.id.spinner);
        String[] items = {"Select Input Type", "Miles", "Kilometers", "Yards"};
        ArrayAdapter arrayAdapter = new ArrayAdapter(this, R.layout.spinner_text, items);
        spinner.setAdapter(arrayAdapter);
        spinner.setSelection(0);

        spinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                if (position > 0) {
                    choice = position;
                } else {
                    Toast.makeText(DistanceActivity2.this, "Please select data type", Toast.LENGTH_SHORT).show();
                }
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {
                Toast.makeText(DistanceActivity2.this, "Please select a type", Toast.LENGTH_SHORT).show();
            }
        });
    }


    public void Convert(View v) {
        //  Could have written this code better to avoid so much repetition

        // input
        if (choice == 1) {
            double conversionK;
            double conversionY;
            double doubleInputM = Double.parseDouble(e1.getText().toString());

            // output
            d1.setTextSize(24);
            d1.setPadding(30,0,0,0);
            d1.setText("" + e1.getText().toString());    // kelvin

            conversionK = doubleInputM * 1.60934;
            d2.setTextSize(24);
            d2.setPadding(30,0,0,0);
            d2.setText("" + df2.format(conversionK));           // celsius

            conversionY = doubleInputM * 1760;
            d3.setTextSize(24);
            d3.setPadding(30,0,0,0);
            d3.setText("" + df2.format(conversionY));           // fahrenheit
        }

        // input
        if (choice == 2) {
            double conversionM;
            double conversionY;
            double doubleInputK = Double.parseDouble(e1.getText().toString());

            // output
            conversionM = doubleInputK * 0.621371;
            d1.setTextSize(24);
            d1.setPadding(30,0,0,0);
            d1.setText("" + df2.format(conversionM));

            d2.setTextSize(24);
            d2.setPadding(30,0,0,0);
            d2.setText("" + e1.getText().toString());

            conversionY = doubleInputK * 1093.61;
            d3.setTextSize(24);
            d3.setPadding(30,0,0,0);
            d3.setText("" + df2.format(conversionY));
        }

        // input
        if (choice == 3) {
            double conversionM;
            double conversionK;
            double doubleInputY = Double.parseDouble(e1.getText().toString());

            // output
            conversionM = doubleInputY / 1760;
            d1.setTextSize(24);
            d1.setPadding(30,0,0,0);
            d1.setText("" + df2.format(conversionM));

            conversionK = doubleInputY / 1094;
            d2.setTextSize(24);
            d2.setPadding(30,0,0,0);
            d2.setText("" + df2.format(conversionK));

            d3.setTextSize(24);
            d3.setPadding(30,0,0,0);
            d3.setText("" + e1.getText().toString());
        }
    }
}