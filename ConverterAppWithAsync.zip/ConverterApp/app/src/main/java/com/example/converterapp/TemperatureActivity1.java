package com.example.converterapp;

import androidx.appcompat.app.AppCompatActivity;
import android.util.Log;
import android.widget.TextView;
import android.widget.EditText;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Spinner;
import android.widget.Toast;
import java.text.DecimalFormat;

/*
 *       This activity has 1 input with 1 Spinner (with 4 values)
 *       and 1 button that produces 3 outputs.
 *
 *       Inputs:
 *       1. Value to convert
 *       2. Spinner:
 *          - "Select Data Type"
 *          - "Kelvin"
 *          - "Celsius"
 *          - "Fahrenheit"
 *
 *       Button with corresponding onClick:
 *       1. Convert     -   Convert()
 *
 *       Outputs:
 *       1. Kelvin
 *       2. Celsius
 *       3. Fahrenheit
 *
 */

public class TemperatureActivity1 extends AppCompatActivity {

    // input
    private EditText e1;
    private Spinner spinner;
    private int choice = 0;

    // output
    private TextView d1;
    private TextView d2;
    private TextView d3;

    private static DecimalFormat df2 = new DecimalFormat("#.##");
    private static final String TAG = "TemperatureActivity1";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_temperature1);

        // input
        e1 = findViewById(R.id.input);

        // output
        d1 = findViewById(R.id.display1);
        d2 = findViewById(R.id.display2);
        d3 = findViewById(R.id.display3);

        Log.d(TAG, "onCreate: Entered TempActivity");
        //getSupportActionBar().setHomeButtonEnabled(true);

        // spinner
        spinner = findViewById(R.id.spinner);
        String[] items = {"Select Input Type", "Kelvin", "Celsius", "Fahrenheit"};
        ArrayAdapter arrayAdapter = new ArrayAdapter(this, R.layout.spinner_text, items);
        spinner.setAdapter(arrayAdapter);
        spinner.setSelection(0);

        spinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener(){

            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                Toast.makeText(TemperatureActivity1.this, ""+parent.getItemAtPosition(position), Toast.LENGTH_SHORT).show();
                if(position > 0){
                    choice = position;
                }else{
                    Toast.makeText(TemperatureActivity1.this, "Please select data type", Toast.LENGTH_SHORT).show();
                }
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {
                Toast.makeText(TemperatureActivity1.this, "Please select a type", Toast.LENGTH_SHORT).show();
            }
        });
    }

    public void Convert(View v){
        //  Could have written this code better to avoid so much repetition

        // input
        if(choice == 1){                //  Kelvin
            double conversionC;
            double conversionF;
            double doubleInputK = Double.parseDouble(e1.getText().toString());

            // output
            d1.setTextSize(24);
            d1.setPadding(30,0,0,0);
            d1.setText("" + e1.getText().toString());    // kelvin

            conversionC = doubleInputK - 273.15;
            d2.setTextSize(24);
            d2.setPadding(30,0,0,0);
            d2.setText("" + df2.format(conversionC));           // celsius

            conversionF = (doubleInputK - 273.15) * 9/5 + 32;
            d3.setTextSize(24);
            d3.setPadding(30,0,0,0);
            d3.setText("" + df2.format(conversionF));           // fahrenheit
        }

        // input
        if(choice == 2){                //  Celsius
            double conversionK;
            double conversionF;
            double doubleInput = Double.parseDouble(e1.getText().toString());

            // output
            conversionK = doubleInput + 273.15;
            d1.setTextSize(24);
            d1.setPadding(30,0,0,0);
            d1.setText("" + df2.format(conversionK));

            d2.setTextSize(24);
            d2.setPadding(30,0,0,0);
            d2.setText("" + e1.getText().toString());

            conversionF = (doubleInput * 9/5) + 32;
            d3.setTextSize(24);
            d3.setPadding(30,0,0,0);
            d3.setText("" + df2.format(conversionF));
        }

        // input
        if(choice == 3){                //  Fahrenheit
            double conversionK;
            double conversionC;
            double doubleInput = Double.parseDouble(e1.getText().toString());

            // output
            conversionK = (doubleInput - 32) * 5/9 + 273.15;
            d1.setTextSize(24);
            d1.setPadding(30,0,0,0);
            d1.setText("" + df2.format(conversionK));

            conversionC = (doubleInput - 32) * 5/9;
            d2.setTextSize(24);
            d2.setPadding(30,0,0,0);
            d2.setText("" + df2.format(conversionC));

            d3.setTextSize(24);
            d3.setPadding(30,0,0,0);
            d3.setText("" + e1.getText().toString());
        }

    }
}
