package com.example.converterapp;

import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.content.Intent;

/*
*       This activity does nothing but direct you
*       to other activities.
*
*       It has 4 buttons and 4 corresponding onClick Method with Intents:
*
*       1. Temperature      -   tempAct()
*       2. Distance         -   distAct()
*       3. Currency         -   currAct()
*       4. Tip Calculator   -   tipCAct()
*
*/

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }

    public void tempAct(View v){
        Intent intent = new Intent(MainActivity.this, TemperatureActivity1.class);
        startActivity(intent);
    }

    public void distAct(View v){
        Intent intent = new Intent(MainActivity.this, DistanceActivity2.class);
        startActivity(intent);
    }

    public void currAct(View v){
        Intent intent = new Intent(MainActivity.this, CurrencyActivity5.class);
        startActivity(intent);
    }

    public void tipCAct(View v){
        Intent intent = new Intent(MainActivity.this, TipCalActivity6.class);
        startActivity(intent);
    }
}
