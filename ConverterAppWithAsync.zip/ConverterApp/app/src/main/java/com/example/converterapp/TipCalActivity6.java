package com.example.converterapp;

import androidx.appcompat.app.AppCompatActivity;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;
import android.os.Bundle;
import android.widget.Toast;
import java.text.DecimalFormat;

/*
 *       This activity has 3 inputs and 1 button that produces 4 outputs.
 *
 *       Inputs:
 *       1. Bill Total
 *       2. Tip Percentage (with Toast if '%' sign entered)
 *       3. Number of People
 *
 *       Button with corresponding onClick:
 *       1. Convert     -   Convert()
 *
 *       Outputs:
 *       1. Bill Total
 *       2. Tip Total
 *       3. Bill for Each with Tip      (Split with tip)
 *       4. Tip for Each                (With Split)
 *
 */

public class TipCalActivity6 extends AppCompatActivity {

    // inputs
    private EditText inputBillTotal;
    private EditText inputPeopleTotal;
    private EditText inputPercentageTotal;
    // outputs
    private TextView display;
    private TextView display1;
    private TextView display2;
    private TextView display3;

    private static DecimalFormat df2 = new DecimalFormat("#.##");

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_tip_cal6);

        // inputs
        inputBillTotal = findViewById(R.id.inputBillTotal);
        inputPeopleTotal = findViewById(R.id.inputPeopleTotal);
        inputPercentageTotal = findViewById(R.id.inputPercentageTotal);

        // outputs
        display = findViewById(R.id.display);
        display1 = findViewById(R.id.display1);
        display2 = findViewById(R.id.display2);
        display3 = findViewById(R.id.display3);
    }

    // Button
    public void Convert(View v) {
        // capture inputs as Strings
        String BillTotal = inputBillTotal.getText().toString();
        String PeopleTotal = inputPeopleTotal.getText().toString();
        String PercentageTotal = inputPercentageTotal.getText().toString();

        // produce toast if input contains "%" symbol else compute
        int checker = PercentageTotal.indexOf("%");
        if (checker > 0) {
            Toast.makeText(this, "Remove '%' enter only number", Toast.LENGTH_SHORT).show();
        } else {
            // parse String to Double
            double Bill;
            try {
                Bill = Double.parseDouble(BillTotal);
            } catch (NumberFormatException e){
                Bill = 0;
            }

            double People;
            try {
                People = Double.parseDouble(PeopleTotal);
            } catch (NumberFormatException e) {
                People = 0;
            }

            double Percentage;
            try {
                Percentage = Double.parseDouble(PercentageTotal);
            } catch (NumberFormatException e) {
                Percentage = 0;
            }

            // Calculate with parsed values
            double tipTotal;
            double tipEach;
            double billEach;

            tipTotal = Bill * (Percentage/100);
            tipEach = tipTotal / People;
            billEach = (Bill / People) + tipEach;

            // output to display (2 decimal places)
            display.setTextSize(24);
            display.setPadding(30,0,0,0);
            double a = (double) Double.parseDouble(df2.format(Bill/People));
            display.setText("$" + df2.format(Bill) + "");
            display1.setTextSize(24);
            display1.setPadding(30,0,0,0);
            display1.setText("$" + df2.format(tipTotal) + "");

            display2.setTextSize(24);
            display2.setPadding(30,0,0,0);
            display2.setText("$" + df2.format(billEach) + "");

            display3.setTextSize(24);
            display3.setPadding(30,0,0,0);
            display3.setText("$" + df2.format(tipEach) + "");
        }
    }
}