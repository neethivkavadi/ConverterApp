package com.example.converterapp;

import android.content.Context;
import android.icu.text.Edits;
import android.os.AsyncTask;
import android.util.Log;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.text.DecimalFormat;
import java.util.Iterator;

import static android.content.ContentValues.TAG;
import static com.example.converterapp.CurrencyActivity5.d1;
import static com.example.converterapp.CurrencyActivity5.d2;
import static com.example.converterapp.CurrencyActivity5.d3;

public class CurrencyAsync extends AsyncTask<Context, Void, Void> {

    private static DecimalFormat df2 = new DecimalFormat("#.##");
    private String param1;
    private String param2;
    private String key = "Wojg2kHfqsQQO9aVdow2HwUAQNLRYPX0s7Ac";
    String data = "";

    double conversionRateINR;
    double conversionRateEUR;
    double conversionRateUSD;

    String INR;
    String USD;
    String EUR;

    public CurrencyAsync(String param1, String param2){
        this.param1 = param1;
        this.param2 = param2;
    }

    @Override
    protected Void doInBackground(Context... params) {
        //Log.d(TAG, "doInBackground: " + param1);

        try {
            URL url = new URL("https://currencyapi.net/api/v1/rates" + "?key=" + key + "&base=" + param1);
            HttpURLConnection httpURLConnection = (HttpURLConnection) url.openConnection();
            InputStream inputStream = httpURLConnection.getInputStream();
            BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(inputStream));
            String line = "";
            while(line!= null) {
                line = bufferedReader.readLine();
                data = data + line;
            }

        } catch (IOException e) {
            e.printStackTrace();
        }
        return null;
    }

    @Override
    protected void onPostExecute(Void aVoid) {
        super.onPostExecute(aVoid);

        try {

            JSONObject obj = new JSONObject(data);
            INR = obj.getJSONObject("rates").getString("INR");
            EUR = obj.getJSONObject("rates").getString("EUR");
            USD = obj.getJSONObject("rates").getString("USD");

            conversionRateINR = Double.parseDouble(INR);
            conversionRateEUR = Double.parseDouble(EUR);
            conversionRateUSD = Double.parseDouble(USD);


        } catch (JSONException e) {
            e.printStackTrace();
            Log.d(TAG, "onPostExecute: EROOR");
        }
        //Log.d(TAG, "doInBackground: " + data);
        //CurrencyActivity5.d3.setText();

        // input
        if (param1 == "INR") {      // Rupee
            double conversionEuro;
            double conversionDollar;
            double doubleInputR = Double.parseDouble(param2);

            // output
            d1.setTextSize(24);
            d1.setPadding(30, 0, 0, 0);
            d1.setText("" + param2);                   // Rupee

            conversionEuro = doubleInputR * 0.011;
            d2.setTextSize(24);
            d2.setPadding(30, 0, 0, 0);
            d2.setText("" + df2.format(conversionEuro));                // Euro

            conversionDollar = doubleInputR * 0.013;
            d3.setTextSize(24);
            d3.setPadding(30, 0, 0, 0);
            d3.setText("" + df2.format(conversionDollar));              // Dollar
        }

        // input
        if (param1 == "EUR") {      // Euro
            double conversionRupee;
            double conversionDollar;
            double doubleInputE = Double.parseDouble(param2);

            // output
            conversionRupee = doubleInputE * 87.81;
            d1.setTextSize(24);
            d1.setPadding(30,0,0,0);
            d1.setText("" + df2.format(conversionRupee));                    // Rupee

            d2.setTextSize(24);
            d2.setPadding(30,0,0,0);
            d2.setText("" + param2);                       // Euro

            conversionDollar = doubleInputE * 1.18;
            d3.setTextSize(24);
            d3.setPadding(30,0,0,0);
            d3.setText("" + df2.format(conversionDollar));                  // Dollar
        }

        // input
        if (param1 == "USD") {      // US Dollar
            double conversionRupee;
            double conversionEuro;
            double conversionDollar;
            double doubleInputK = Double.parseDouble(param2);

            // output
            conversionRupee = doubleInputK * conversionRateINR;
            d1.setTextSize(24);
            d1.setPadding(30,0,0,0);
            d1.setText("" + df2.format(conversionRupee));           // Rupee

            conversionEuro = doubleInputK * conversionRateEUR;
            d2.setTextSize(24);
            d2.setPadding(30,0,0,0);
            d2.setText("" + df2.format(conversionEuro));           // Euro

            conversionDollar = doubleInputK * conversionRateUSD;
            d3.setTextSize(24);
            d3.setPadding(30,0,0,0);
            d3.setText("" + df2.format(conversionDollar));    // Dollar
        }
    }
}
