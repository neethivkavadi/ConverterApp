package com.example.converterapp;

import androidx.appcompat.app.AppCompatActivity;

import android.os.AsyncTask;
import android.view.View;
import android.widget.EditText;
import android.widget.Spinner;
import android.os.Bundle;
import android.widget.TextView;
import java.text.DecimalFormat;
import android.widget.ArrayAdapter;
import android.widget.AdapterView;
import android.widget.Toast;

/*
 *       This activity has 1 input with 1 Spinner (with 4 values)
 *       and 1 button that produces 3 outputs.
 *
 *       Inputs:
 *       1. Value to convert
 *       2. Spinner:
 *          - "Select Data Type"
 *          - "IND Rupee"
 *          - "Euro"
 *          - "Dollar"
 *
 *       Button with corresponding onClick:
 *       1. Convert     -   Convert()
 *
 *       Outputs:
 *       1. IND Rupee
 *       2. Euros
 *       3. Dollar
 *
 */

public class CurrencyActivity5 extends AppCompatActivity {

    private String input;

    // Input with Spinner
    private EditText e1;
    private Spinner spinner;
    private int choice = 0;     // choice on Spinner

    // Output
    public static TextView d1;
    public static TextView d2;
    public static TextView d3;

    private static DecimalFormat df2 = new DecimalFormat("#.##");
    private static final String TAG = "CurrencyActivity5";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_currency5);

        // input
        e1 = findViewById(R.id.input);

        // output
        d1 = findViewById(R.id.display1);
        d2 = findViewById(R.id.display2);
        d3 = findViewById(R.id.display3);

        // spinner
        spinner = findViewById(R.id.spinner);
        String[] items = {"Select Input Type", "IND Rupee", "Euro", "US Dollar"};
        ArrayAdapter arrayAdapter = new ArrayAdapter(this, R.layout.spinner_text, items);
        spinner.setAdapter(arrayAdapter);
        spinner.setSelection(0);
        spinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {

            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                if (position > 0) {
                    choice = position;
                } else {
                    Toast.makeText(CurrencyActivity5.this, "Please select data type", Toast.LENGTH_SHORT).show();
                }
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {
                Toast.makeText(CurrencyActivity5.this, "Please select a type", Toast.LENGTH_SHORT).show();
            }
        });
    }

    public void Convert(View v) {
        //  Could have written this code better to avoid so much repetition
        if(choice == 1){
            input = "INR";
        }else if(choice == 2){
            input = "EUR";
        }else if(choice == 3){
            input = "USD";
        }else{
            Toast.makeText(this, "Please make a selection", Toast.LENGTH_SHORT).show();
        }

        AsyncTask asyncTask = new CurrencyAsync(input, e1.getText().toString()).execute();

        // input
        if (choice == 1) {      // Rupee
            double conversionEuro;
            double conversionDollar;
            double doubleInputR = Double.parseDouble(e1.getText().toString());

            // output
            if (doubleInputR > -1){
                d1.setTextSize(24);
                d1.setPadding(30, 0, 0, 0);
                d1.setText("" + e1.getText().toString());                   // Rupee

                conversionEuro = doubleInputR * 0.011;
                d2.setTextSize(24);
                d2.setPadding(30, 0, 0, 0);
                d2.setText("" + df2.format(conversionEuro));                // Euro

                conversionDollar = doubleInputR * 0.013;
                d3.setTextSize(24);
                d3.setPadding(30, 0, 0, 0);
                d3.setText("" + df2.format(conversionDollar));              // Dollar
            }else{
                Toast.makeText(this, "", Toast.LENGTH_SHORT).show();
            }
        }

        // input
        if (choice == 2) {      // Euro
            double conversionRupee;
            double conversionDollar;
            double doubleInputE = Double.parseDouble(e1.getText().toString());

            // output
            conversionRupee = doubleInputE * 87.81;
            d1.setTextSize(24);
            d1.setPadding(30,0,0,0);
            d1.setText("" + df2.format(conversionRupee));                    // Rupee

            d2.setTextSize(24);
            d2.setPadding(30,0,0,0);
            d2.setText("" + e1.getText().toString());                       // Euro

            conversionDollar = doubleInputE * 1.18;
            d3.setTextSize(24);
            d3.setPadding(30,0,0,0);
            d3.setText("" + df2.format(conversionDollar));                  // Dollar
        }

        // input
        if (choice == 3) {      // US Dollar
            double conversionRupee;
            double conversionEuro;
            double doubleInputK = Double.parseDouble(e1.getText().toString());

            // output
            conversionRupee = doubleInputK * 74.58;
            d1.setTextSize(24);
            d1.setPadding(30,0,0,0);
            d1.setText("" + df2.format(conversionRupee));           // Rupee

            conversionEuro = doubleInputK * 0.85;
            d2.setTextSize(24);
            d2.setPadding(30,0,0,0);
            d2.setText("" + df2.format(conversionEuro));           // Euro

            d3.setTextSize(24);
            d3.setPadding(30,0,0,0);
            d3.setText("" + e1.getText().toString());    // Dollar
        }
    }
}
